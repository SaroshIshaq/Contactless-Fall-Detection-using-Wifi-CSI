#!/usr/bin/env python3
"""Round-trip test for feitcsi_parse.py using a synthetic .dat that mimics
Csi::save() exactly (272-byte packed header + int16 LE complex payload)."""
import os
import struct
import sys
import math

sys.path.insert(0, "/mnt/c/Users/mahwi/Downloads/FeitCSI-master")
import feitcsi_parse as fp

HDR = struct.Struct("<IIIQ26sBB4sI4sII6s18sI176s")
assert HDR.size == 272

TMP = "/tmp/feitcsi_test"
os.makedirs(TMP, exist_ok=True)


def make_header(csi_data_size, timestamp, num_rx, num_tx, num_sc,
                rssi1, rssi2, src_mac, rate_n_flag):
    return HDR.pack(csi_data_size, 0, 0, timestamp, b"\x00" * 26,
                    num_rx, num_tx, b"\x00" * 4, num_sc, b"\x00" * 4,
                    rssi1, rssi2, src_mac, b"\x00" * 18, rate_n_flag,
                    b"\x00" * 176)


def make_payload(samples):
    """samples = list of (real, imag) int16 -> bytes (real LE, imag LE)."""
    out = b""
    for r, i in samples:
        out += struct.pack("<hh", r, i)
    return out


def gen_uniform(path, n_frames=3):
    """2x2x4 HE/80 frames with known values."""
    rx, tx, ns = 2, 2, 4
    rate = (4 << 8) | (2 << 11)  # HE, 80 MHz
    mac = bytes([0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff])
    with open(path, "wb") as f:
        for fr in range(n_frames):
            samples = [(k + 1, -(k + 1)) for k in range(rx * tx * ns)]
            payload = make_payload(samples)
            f.write(make_header(len(payload), 1_000_000 + fr * 5000,
                                rx, tx, ns, 50, 60, mac, rate))
            f.write(payload)


def gen_ragged(path):
    """Two frames with different subcarrier counts (width changed mid-capture)."""
    mac = bytes([0x11, 0x22, 0x33, 0x44, 0x55, 0x66])
    rate = (3 << 8) | (1 << 11)  # VHT, 40 MHz
    with open(path, "wb") as f:
        for ns in (6, 10):
            samples = [(3, 4)] * (1 * 1 * ns)  # magnitude 5 each
            payload = make_payload(samples)
            f.write(make_header(len(payload), 2_000_000, 1, 1, ns,
                                40, 0, mac, rate))
            f.write(payload)


checks = []


def check(name, cond):
    checks.append((name, cond))
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}")


# --- Test 1: uniform capture -------------------------------------------------
print("Test 1: uniform 2x2x4 HE/80 capture")
p1 = os.path.join(TMP, "uniform.dat")
gen_uniform(p1)
frames = fp.parse_dat(p1)
check("3 frames parsed", len(frames) == 3)
f0 = frames[0]
check("num_rx=2", f0.num_rx == 2)
check("num_tx=2", f0.num_tx == 2)
check("num_subcarriers=4", f0.num_subcarriers == 4)
check("csi shape (2,2,4)", f0.csi.shape == (2, 2, 4))
check("src_mac decodes", f0.src_mac_str == "aa:bb:cc:dd:ee:ff")
check("format=HE", f0.format_name == "HE")
check("width=80", f0.width_mhz == 80)
check("rssi1=50 rssi2=60", f0.rssi1 == 50 and f0.rssi2 == 60)
check("timestamp frame0", f0.timestamp == 1_000_000)
check("timestamp frame2", frames[2].timestamp == 1_010_000)
# sample 0 = real 1, imag -1 -> magnitude sqrt(2), phase -pi/4
check("magnitude[0,0,0]=sqrt2", abs(f0.magnitude[0, 0, 0] - math.sqrt(2)) < 1e-9)
check("phase[0,0,0]=-pi/4", abs(f0.phase[0, 0, 0] - (-math.pi / 4)) < 1e-9)
# ordering: flat index (r*tx + t)*ns + s ; sample k = real k+1
# csi[1,0,2] -> flat (1*2+0)*4+2 = 10 -> real 11
check("ordering csi[1,0,2].real=11", f0.csi[1, 0, 2].real == 11)
check("ordering csi[1,0,2].imag=-11", f0.csi[1, 0, 2].imag == -11)
check("uniform shape detected", fp._uniform(frames))

# --- Test 2: npz / csv / meta writers ---------------------------------------
print("Test 2: writers")
prefix = os.path.join(TMP, "uniform")
fp.write_npz(frames, prefix + ".npz")
fp.write_csv(frames, prefix + ".csv")
fp.write_meta_csv(frames, prefix + "_meta.csv")
import numpy as np
z = np.load(prefix + ".npz")
check("npz magnitude shape (3,2,2,4)", z["magnitude"].shape == (3, 2, 2, 4))
check("npz phase shape (3,2,2,4)", z["phase"].shape == (3, 2, 2, 4))
check("npz timestamps len 3", len(z["timestamps"]) == 3)
check("npz src_mac shape (3,6)", z["src_mac"].shape == (3, 6))
check("npz magnitude[0,0,0,0]=sqrt2", abs(z["magnitude"][0, 0, 0, 0] - math.sqrt(2)) < 1e-9)
csv_rows = sum(1 for _ in open(prefix + ".csv")) - 1
check("csv rows = 3*2*2*4=48", csv_rows == 48)
meta_rows = sum(1 for _ in open(prefix + "_meta.csv")) - 1
check("meta csv rows = 3", meta_rows == 3)

# --- Test 3: load_magnitude convenience -------------------------------------
print("Test 3: load_magnitude")
mag = fp.load_magnitude(p1)
check("load_magnitude shape (3,2,2,4)", mag.shape == (3, 2, 2, 4))

# --- Test 4: ragged capture -> NaN padding ----------------------------------
print("Test 4: ragged capture (ns 6 and 10)")
p2 = os.path.join(TMP, "ragged.dat")
gen_ragged(p2)
rframes = fp.parse_dat(p2)
check("2 ragged frames", len(rframes) == 2)
check("not uniform", not fp._uniform(rframes))
stacked = fp._stack(rframes, "magnitude")
check("stacked shape (2,1,1,10)", stacked.shape == (2, 1, 1, 10))
check("frame0 padded NaN at sc=6", math.isnan(stacked[0, 0, 0, 6]))
check("frame0 valid mag=5 at sc=0", abs(stacked[0, 0, 0, 0] - 5.0) < 1e-9)
check("frame1 valid mag=5 at sc=9", abs(stacked[1, 0, 0, 9] - 5.0) < 1e-9)

# --- Test 5: drop_pilots (HE/80) --------------------------------------------
print("Test 5: drop_pilots")
p3 = os.path.join(TMP, "pilots.dat")
# HE/80 has 996 subcarriers per Csi.h table; build a 1x1x996 frame
rx, tx, ns = 1, 1, 996
rate = (4 << 8) | (2 << 11)
mac = bytes([0xde, 0xad, 0xbe, 0xef, 0x00, 0x01])
with open(p3, "wb") as f:
    payload = make_payload([(1, 0)] * (rx * tx * ns))
    f.write(make_header(len(payload), 3_000_000, rx, tx, ns, 0, 0, mac, rate))
    f.write(payload)
pframes = fp.parse_dat(p3)
before = pframes[0].csi.shape[2]
fp.drop_pilots(pframes)
after = pframes[0].csi.shape[2]
n_pilots = len([p for p in fp._PILOT_INDICES[("HE", 80)] if p < before])
check(f"HE/80 pilots dropped ({before}->{after}, expected -{n_pilots})",
      after == before - n_pilots)

# --- Test 6: truncated / partial file handling ------------------------------
print("Test 6: robustness")
p4 = os.path.join(TMP, "truncated.dat")
gen_uniform(p4, n_frames=2)
with open(p4, "r+b") as f:
    f.seek(0, 2)
    sz = f.tell()
    f.truncate(sz - 5)  # chop 5 bytes off the last payload
tframes = fp.parse_dat(p4)
check("truncated last frame dropped, 1 full frame kept", len(tframes) == 1)

# --- Summary -----------------------------------------------------------------
passed = sum(1 for _, c in checks if c)
total = len(checks)
print(f"\n{passed}/{total} checks passed")
sys.exit(0 if passed == total else 1)
