#!/usr/bin/env python3
"""Validate baseline_fall_detection.py: (a) demo path + plot, (b) real-data
ingestion path (--npz --labels) using a parser-format .npz with a fall event."""
import json
import os
import sys

import numpy as np

sys.path.insert(0, "/mnt/c/Users/mahwi/Downloads/FeitCSI-master")
import baseline_fall_detection as ml

TMP = "/tmp/feitcsi_ml_test"
os.makedirs(TMP, exist_ok=True)
checks = []


def check(name, cond):
    checks.append((name, cond))
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}")


def runs_to_intervals(labels, fs):
    idx = np.where(np.asarray(labels) == 1)[0]
    if idx.size == 0:
        return []
    out, start, prev = [], idx[0], idx[0]
    for i in idx[1:]:
        if i == prev + 1:
            prev = i
        else:
            out.append([round(start / fs, 4), round(prev / fs, 4)])
            start = prev = i
    out.append([round(start / fs, 4), round(prev / fs, 4)])
    return out


# --- (a) demo path + plot ----------------------------------------------------
print("Test A: --demo end-to-end (+ --plot)")
png = os.path.join(TMP, "demo.png")
rc = ml.main(["--demo", "--seed", "1", "--plot", png])
check("demo returns 0", rc == 0)
check("plot PNG written", os.path.isfile(png) and os.path.getsize(png) > 0)

# --- (b) real-data ingestion path -------------------------------------------
print("\nTest B: --npz --labels ingestion (parser-format .npz)")
demo = ml.gen_demo(n_subjects=1, duration_sec=30, fs=200, n_falls=3, n_sub=52, seed=7)[0]
sig = demo["sig"]                       # (F, Ns)
F, Ns = sig.shape
fs = demo["fs"]
# magnitude shaped like feitcsi_parse.write_npz output: (F, Rx, Tx, Ns)
mag = sig.reshape(F, 1, 1, Ns)
timestamps = (np.arange(F) * (1e6 / fs)).astype(np.uint64)   # microseconds
npz_path = os.path.join(TMP, "run1.npz")
np.savez_compressed(npz_path, magnitude=mag, timestamps=timestamps,
                    num_subcarriers=np.array([Ns] * F, dtype=np.uint32))

intervals = runs_to_intervals(demo["frame_labels"], fs)
labels_path = os.path.join(TMP, "labels.json")
with open(labels_path, "w") as fh:
    json.dump({os.path.basename(npz_path): intervals}, fh)
print(f"  wrote {npz_path} ({F} frames) + labels.json with {len(intervals)} fall intervals")

rc = ml.main(["--npz", npz_path, "--labels", labels_path, "--fs", str(int(fs)), "-v"])
check("real-path returns 0", rc == 0)

# verify labeling logic directly
cap = ml.load_capture(npz_path)
check("load_capture shape (F,Ns)", cap["sig"].shape == (F, Ns))
check("fs estimated ~200", abs(cap["fs"] - 200) < 5)
fl = ml.labels_from_intervals(cap["t_sec"], F, intervals)
check("labels_from_intervals marks falls", fl.sum() > 0)
check("labeled frames match generator", abs(fl.sum() - demo["frame_labels"].sum()) < 0.05 * F)

# --- (c) plain-list labels for single npz -----------------------------------
print("\nTest C: --labels as a plain list (single --npz)")
with open(labels_path, "w") as fh:
    json.dump(intervals, fh)
rc = ml.main(["--npz", npz_path, "--labels", labels_path, "--fs", str(int(fs))])
check("plain-list labels returns 0", rc == 0)

passed = sum(1 for _, c in checks if c)
print(f"\n{passed}/{len(checks)} checks passed")
sys.exit(0 if passed == len(checks) else 1)
