#!/usr/bin/env python3
"""
feitcsi_parse.py — Parse FeitCSI .dat binary captures into NumPy (.npz) / CSV.

Binary format (verified against FeitCSI source: include/Csi.h + src/Csi.cpp):

  The .dat file is a plain concatenation of records. Each record is:
      [ 272-byte RawHeaderData header ][ csiDataSize bytes of CSI payload ]
  Csi::save() opens the file in append mode and writes header+payload per frame,
  so records sit back-to-back with no separators.

  Header struct is __attribute__((__packed__)) and x86 little-endian.
  Payload = csiDataSize/4 complex samples; each sample is 4 bytes:
      int16 LE real, int16 LE imag          (Csi::processRawCsi)
  magnitude = abs(real + j*imag); phase = atan2(imag, real).

  Sample ordering (Csi::unwrapPhase / fixCsiBug loops are rx -> tx -> subcarrier):
      flat_index = (rx * numTx + tx) * numSubCarriers + subcarrier

Header layout (offset, size, field, type):
   0   4   csiDataSize     uint32
   4   4   space4          uint32
   8   4   ftmClock        uint32
  12   8   timestamp       uint64   (device units; driver commonly microseconds)
  20  26   space20         bytes
  46   1   numRx           uint8
  47   1   numTx           uint8
  48   4   space48         bytes
  52   4   numSubCarriers  uint32
  56   4   space54         bytes
  60   4   rssi1           uint32
  64   4   rssi2           uint32
  68   6   srcMac          bytes
  74  18   space75         bytes
  92   4   rateNflag       uint32
  96 176   space96         bytes
  -----------------------------
  = 272 bytes (CSI_HEADER_LENGTH)

rateNflag decode (lib/include/rs.h):
  format        = (rateNflag & 0x700)  >> 8    0=CCK 1=LEGACY_OFDM 2=HT 3=VHT 4=HE 5=EHT
  channel_width = (rateNflag & 0x3800) >> 11   0=20 1=40 2=80 3=160 4=320 (MHz)

Usage:
  python3 feitcsi_parse.py capture.dat                 # -> capture.npz
  python3 feitcsi_parse.py capture.dat --info          # print summary, write nothing
  python3 feitcsi_parse.py capture.dat --csv           # also write tidy long CSV
  python3 feitcsi_parse.py capture.dat --drop-pilots   # remove pilot subcarriers
  python3 feitcsi_parse.py capture.dat -o run1         # output prefix = run1.*

Requires: numpy (stdlib for everything else).
"""

import argparse
import csv
import os
import struct
import sys
from dataclasses import dataclass

import numpy as np

# --- Header definition -------------------------------------------------------

CSI_HEADER_LENGTH = 272

# <  = little-endian, standard sizes, NO alignment/padding (matches __packed__)
_HEADER_FMT = "<IIIQ26sBB4sI4sII6s18sI176s"
_HEADER = struct.Struct(_HEADER_FMT)
assert _HEADER.size == CSI_HEADER_LENGTH, (
    f"header struct is {_HEADER.size} bytes, expected {CSI_HEADER_LENGTH}"
)

_FORMAT_NAMES = {0: "CCK", 1: "LEGACY_OFDM", 2: "HT", 3: "VHT", 4: "HE", 5: "EHT"}
_WIDTH_NAMES = {0: 20, 1: 40, 2: 80, 3: 160, 4: 320}

_RATE_MCS_MOD_TYPE_MSK = 0x7 << 8       # 0x700
_RATE_MCS_CHAN_WIDTH_MSK = 0x7 << 11    # 0x3800

# Pilot subcarrier indices, keyed by (format_name, width_mhz). From Csi.h.
# LEGACY_OFDM uses the NOHT table; HT and VHT share tables; HE has its own.
_PILOT_INDICES = {
    ("LEGACY_OFDM", 20): [5, 19, 32, 46],
    ("HT", 20): [7, 21, 34, 48],
    ("HT", 40): [5, 33, 47, 66, 80, 108],
    ("VHT", 20): [7, 21, 34, 48],
    ("VHT", 40): [5, 33, 47, 66, 80, 108],
    ("VHT", 80): [19, 47, 83, 111, 130, 158, 194, 222],
    ("VHT", 160): [19, 47, 83, 111, 130, 158, 194, 222,
                   261, 289, 325, 353, 372, 400, 436, 464],
    ("HE", 20): [6, 32, 74, 100, 141, 167, 209, 235],
    ("HE", 40): [6, 32, 74, 100, 140, 166, 208, 234,
                 249, 275, 317, 343, 383, 409, 451, 477],
    ("HE", 80): [32, 100, 166, 234, 274, 342, 408, 476,
                 519, 587, 653, 721, 761, 829, 895, 963],
    ("HE", 160): [32, 100, 166, 234, 274, 342, 408, 476, 519, 587, 653, 721,
                  761, 829, 895, 963, 1028, 1096, 1162, 1230, 1270, 1338,
                  1404, 1472, 1515, 1583, 1649, 1717, 1757, 1825, 1891, 1959],
}


@dataclass
class Frame:
    """One decoded CSI record."""
    index: int
    timestamp: int
    src_mac: bytes
    num_rx: int
    num_tx: int
    num_subcarriers: int
    rssi1: int
    rssi2: int
    rate_n_flag: int
    format_code: int
    width_code: int
    csi_data_size: int
    # complex samples reshaped to (num_rx, num_tx, num_subcarriers); flat frames
    # that don't factor cleanly are stored as (1, 1, n_samples).
    csi: np.ndarray

    @property
    def format_name(self) -> str:
        return _FORMAT_NAMES.get(self.format_code, f"UNKNOWN({self.format_code})")

    @property
    def width_mhz(self) -> int:
        return _WIDTH_NAMES.get(self.width_code, 0)

    @property
    def src_mac_str(self) -> str:
        return ":".join(f"{b:02x}" for b in self.src_mac)

    @property
    def magnitude(self) -> np.ndarray:
        return np.abs(self.csi)

    @property
    def phase(self) -> np.ndarray:
        return np.angle(self.csi)


def _decode_payload(payload: bytes, num_rx: int, num_tx: int,
                    num_subcarriers: int, verbose: bool = False) -> np.ndarray:
    """Turn raw payload bytes into a complex array shaped (rx, tx, subcarrier)."""
    n_samples = len(payload) // 4
    i16 = np.frombuffer(payload[: n_samples * 4], dtype="<i2")
    real = i16[0::2].astype(np.float64)
    imag = i16[1::2].astype(np.float64)
    csi = real + 1j * imag

    expected = num_rx * num_tx * num_subcarriers
    if expected == n_samples and expected > 0:
        return csi.reshape(num_rx, num_tx, num_subcarriers)

    if verbose:
        print(f"  [warn] payload has {n_samples} samples but header implies "
              f"{num_rx}x{num_tx}x{num_subcarriers}={expected}; storing flat",
              file=sys.stderr)
    return csi.reshape(1, 1, n_samples)


def parse_dat(path: str, verbose: bool = False) -> list:
    """Read every record in a FeitCSI .dat file. Returns a list of Frame."""
    frames = []
    size = os.path.getsize(path)
    with open(path, "rb") as f:
        idx = 0
        while True:
            header = f.read(CSI_HEADER_LENGTH)
            if len(header) == 0:
                break  # clean EOF
            if len(header) < CSI_HEADER_LENGTH:
                print(f"[warn] trailing {len(header)} bytes ignored (partial header)",
                      file=sys.stderr)
                break

            (csi_data_size, _space4, _ftm_clock, timestamp, _space20,
             num_rx, num_tx, _space48, num_subcarriers, _space54,
             rssi1, rssi2, src_mac, _space75, rate_n_flag, _space96) = _HEADER.unpack(header)

            if csi_data_size == 0 or csi_data_size > size:
                print(f"[warn] frame {idx}: implausible csiDataSize={csi_data_size}; stopping",
                      file=sys.stderr)
                break

            payload = f.read(csi_data_size)
            if len(payload) < csi_data_size:
                print(f"[warn] frame {idx}: truncated payload "
                      f"({len(payload)}/{csi_data_size}); stopping", file=sys.stderr)
                break

            csi = _decode_payload(payload, num_rx, num_tx, num_subcarriers, verbose)
            frames.append(Frame(
                index=idx, timestamp=timestamp, src_mac=src_mac,
                num_rx=num_rx, num_tx=num_tx, num_subcarriers=num_subcarriers,
                rssi1=rssi1, rssi2=rssi2, rate_n_flag=rate_n_flag,
                format_code=(rate_n_flag & _RATE_MCS_MOD_TYPE_MSK) >> 8,
                width_code=(rate_n_flag & _RATE_MCS_CHAN_WIDTH_MSK) >> 11,
                csi_data_size=csi_data_size, csi=csi,
            ))
            idx += 1
    return frames


def _stack(frames: list, attr: str) -> np.ndarray:
    """
    Stack a per-frame complex/real attribute into (F, Rx, Tx, Ns), NaN-padding
    the subcarrier/rx/tx axes when frames differ (e.g. channel width changed
    mid-capture). Uniform captures stack with no padding.
    """
    arrays = [getattr(f, attr) if attr != "csi" else f.csi for f in frames]
    rx = max(a.shape[0] for a in arrays)
    tx = max(a.shape[1] for a in arrays)
    ns = max(a.shape[2] for a in arrays)
    out = np.full((len(arrays), rx, tx, ns), np.nan, dtype=arrays[0].dtype)
    for i, a in enumerate(arrays):
        out[i, : a.shape[0], : a.shape[1], : a.shape[2]] = a
    return out


def drop_pilots(frames: list, verbose: bool = False) -> None:
    """Remove pilot subcarriers in-place using the (format, width) tables."""
    for f in frames:
        # only meaningful when the frame kept its true (rx,tx,ns) shape
        ns = f.csi.shape[2]
        if ns != f.num_subcarriers:
            continue
        key = (f.format_name, f.width_mhz)
        pilots = _PILOT_INDICES.get(key)
        if not pilots:
            if verbose:
                print(f"  [warn] no pilot table for {key}; frame {f.index} unchanged",
                      file=sys.stderr)
            continue
        keep = np.setdiff1d(np.arange(ns), np.array([p for p in pilots if p < ns]))
        f.csi = f.csi[:, :, keep]
        f.num_subcarriers = len(keep)


def write_npz(frames: list, out_path: str) -> None:
    magnitude = np.stack([f.magnitude for f in frames]) if _uniform(frames) else _stack(frames, "magnitude")
    phase = np.stack([f.phase for f in frames]) if _uniform(frames) else _stack(frames, "phase")
    real = _stack(frames, "real") if not _uniform(frames) else np.stack([f.csi.real for f in frames])
    imag = _stack(frames, "imag") if not _uniform(frames) else np.stack([f.csi.imag for f in frames])

    np.savez_compressed(
        out_path,
        magnitude=magnitude,
        phase=phase,
        real=real,
        imag=imag,
        timestamps=np.array([f.timestamp for f in frames], dtype=np.uint64),
        src_mac=np.array([list(f.src_mac) for f in frames], dtype=np.uint8),
        rssi1=np.array([f.rssi1 for f in frames], dtype=np.uint32),
        rssi2=np.array([f.rssi2 for f in frames], dtype=np.uint32),
        format_code=np.array([f.format_code for f in frames], dtype=np.uint8),
        width_code=np.array([f.width_code for f in frames], dtype=np.uint8),
        num_rx=np.array([f.num_rx for f in frames], dtype=np.uint8),
        num_tx=np.array([f.num_tx for f in frames], dtype=np.uint8),
        num_subcarriers=np.array([f.num_subcarriers for f in frames], dtype=np.uint32),
        rate_n_flag=np.array([f.rate_n_flag for f in frames], dtype=np.uint32),
    )


def _uniform(frames: list) -> bool:
    shapes = {f.csi.shape for f in frames}
    return len(shapes) == 1


def write_csv(frames: list, out_path: str) -> None:
    """Tidy long-format CSV: one row per (frame, rx, tx, subcarrier)."""
    with open(out_path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["frame", "timestamp", "src_mac", "format", "channel_width_mhz",
                    "rssi1", "rssi2", "rx", "tx", "subcarrier",
                    "real", "imag", "magnitude", "phase"])
        for f in frames:
            mag = f.magnitude
            pha = f.phase
            rx_n, tx_n, ns = f.csi.shape
            for r in range(rx_n):
                for t in range(tx_n):
                    for s in range(ns):
                        w.writerow([f.index, f.timestamp, f.src_mac_str,
                                    f.format_name, f.width_mhz, f.rssi1, f.rssi2,
                                    r, t, s,
                                    f"{f.csi[r, t, s].real:.6f}",
                                    f"{f.csi[r, t, s].imag:.6f}",
                                    f"{mag[r, t, s]:.6f}",
                                    f"{pha[r, t, s]:.6f}"])


def write_meta_csv(frames: list, out_path: str) -> None:
    """Lightweight per-frame metadata CSV (one row per frame)."""
    with open(out_path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["frame", "timestamp", "src_mac", "format", "channel_width_mhz",
                    "num_rx", "num_tx", "num_subcarriers", "rssi1", "rssi2",
                    "csi_data_size", "rate_n_flag"])
        for f in frames:
            w.writerow([f.index, f.timestamp, f.src_mac_str, f.format_name,
                        f.width_mhz, f.num_rx, f.num_tx, f.num_subcarriers,
                        f.rssi1, f.rssi2, f.csi_data_size, f.rate_n_flag])


def print_info(frames: list, path: str) -> None:
    if not frames:
        print(f"{path}: no frames parsed")
        return
    f0 = frames[0]
    macs = sorted({f.src_mac_str for f in frames})
    fmts = sorted({(f.format_name, f.width_mhz) for f in frames})
    ts = np.array([f.timestamp for f in frames], dtype=np.uint64)
    span = (ts[-1] - ts[0]) if len(ts) > 1 else 0
    rate = (len(frames) - 1) / (span / 1e6) if span > 0 else float("nan")

    print(f"File:            {path}")
    print(f"Size:            {os.path.getsize(path)} bytes")
    print(f"Frames:          {len(frames)}")
    print(f"First frame:     rx={f0.num_rx} tx={f0.num_tx} "
          f"subcarriers={f0.num_subcarriers} csiDataSize={f0.csi_data_size}")
    print(f"CSI array shape: {f0.csi.shape} (rx, tx, subcarrier)")
    print(f"Format(s):       " + ", ".join(f"{n}/{w}MHz" for n, w in fmts))
    print(f"Source MAC(s):   " + ", ".join(macs))
    print(f"RSSI1 range:     {min(f.rssi1 for f in frames)}..{max(f.rssi1 for f in frames)}")
    if span > 0:
        print(f"Timestamp span:  {span} (device units)")
        print(f"Est. CSI rate:   {rate:.1f} Hz  "
              f"(target for falls: 100-1000 Hz)")
    uniform = "yes" if _uniform(frames) else "NO (ragged - shapes differ)"
    print(f"Uniform shape:   {uniform}")


def load_magnitude(path: str) -> np.ndarray:
    """Convenience for ML code: return magnitude array shaped (F, Rx, Tx, Ns)."""
    frames = parse_dat(path)
    if not frames:
        raise ValueError(f"no frames in {path}")
    if _uniform(frames):
        return np.stack([f.magnitude for f in frames])
    return _stack(frames, "magnitude")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="Parse FeitCSI .dat captures into NumPy/CSV.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("input", help="input .dat file")
    ap.add_argument("-o", "--output-prefix", default=None,
                    help="output filename prefix (default: input basename)")
    ap.add_argument("--csv", action="store_true",
                    help="also write tidy long-format CSV (can be large)")
    ap.add_argument("--meta-csv", action="store_true",
                    help="also write per-frame metadata CSV")
    ap.add_argument("--drop-pilots", action="store_true",
                    help="remove pilot subcarriers using (format,width) tables")
    ap.add_argument("--info", action="store_true",
                    help="print a summary and exit without writing files")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)

    if not os.path.isfile(args.input):
        print(f"error: no such file: {args.input}", file=sys.stderr)
        return 2

    frames = parse_dat(args.input, verbose=args.verbose)
    if not frames:
        print("error: parsed 0 frames - is this a FeitCSI .dat file?", file=sys.stderr)
        return 1

    if args.drop_pilots:
        drop_pilots(frames, verbose=args.verbose)
        if args.verbose:
            print(f"dropped pilots; first frame now {frames[0].csi.shape}",
                  file=sys.stderr)

    if args.info:
        print_info(frames, args.input)
        return 0

    prefix = args.output_prefix or os.path.splitext(args.input)[0]
    npz_path = prefix + ".npz"
    write_npz(frames, npz_path)
    print(f"wrote {npz_path}  ({len(frames)} frames)")

    if args.meta_csv:
        meta_path = prefix + "_meta.csv"
        write_meta_csv(frames, meta_path)
        print(f"wrote {meta_path}")

    if args.csv:
        csv_path = prefix + ".csv"
        write_csv(frames, csv_path)
        print(f"wrote {csv_path}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
