#!/usr/bin/env python3
"""
baseline_fall_detection.py — baseline Wi-Fi CSI fall detection over FeitCSI captures.

Reads the .npz produced by feitcsi_parse.py, preprocesses CSI magnitude, slides a
time window, extracts discriminative features, and trains a Random Forest with
SUBJECT-WISE cross-validation (groups kept intact so near-duplicate windows from
one fall never straddle train/test — random window splits leak and inflate scores).

Run it two ways:
  1) Demo (no hardware/data needed) — synthetic labeled multi-subject capture:
       python3 baseline_fall_detection.py --demo
  2) Real capture(s) + labels:
       python3 baseline_fall_detection.py --npz run1.npz run2.npz --labels labels.json
     labels.json maps each capture to fall intervals in SECONDS from capture start:
       {"run1.npz": [[12.3, 13.1], [40.0, 41.2]], "run2.npz": []}
     A plain list [[s,e], ...] is accepted when a single --npz is given.
     Each capture is treated as one group (subject/trial) for grouped CV.

Pipeline: load -> collapse rx/tx -> denoise -> remove static -> normalize
          -> window -> features -> RandomForest -> grouped CV -> metrics.

Requires: numpy, scikit-learn. Optional: scipy (zero-phase denoise), matplotlib (--plot).
"""

import argparse
import json
import os
import sys

import numpy as np

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedGroupKFold, StratifiedKFold
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score

try:
    from scipy.signal import butter, sosfiltfilt
    _HAVE_SCIPY = True
except Exception:
    _HAVE_SCIPY = False

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    _HAVE_MPL = True
except Exception:
    _HAVE_MPL = False


# --- Loading -----------------------------------------------------------------

def estimate_fs(timestamps, override=None):
    """Sampling rate in Hz. Timestamps are device units; FeitCSI/the parser treat
    them as microseconds, so fs = 1e6 / median_diff. Override wins if given."""
    if override:
        return float(override)
    ts = np.asarray(timestamps, dtype=np.float64)
    if ts.size < 2:
        return 100.0
    d = np.median(np.diff(ts))
    if d <= 0:
        return 100.0
    return float(1e6 / d)


def collapse_magnitude(mag):
    """(F, Rx, Tx, Ns) or (F, Ns) magnitude -> (F, Ns), NaN-aware (parser pads
    ragged captures with NaN). Returns (F, Ns) float array."""
    mag = np.asarray(mag, dtype=np.float64)
    if mag.ndim == 4:                      # (F, Rx, Tx, Ns)
        mag = np.nanmean(mag, axis=(1, 2))
    elif mag.ndim == 3:                    # (F, Rx*Tx, Ns) or (F, Ns, ?) - assume (F, pairs, Ns)
        mag = np.nanmean(mag, axis=1)
    if mag.ndim != 2:
        raise ValueError(f"unexpected magnitude shape {mag.shape}")
    return np.nan_to_num(mag, nan=0.0)


def load_capture(npz_path):
    """Load one parser .npz -> dict(sig (F,Ns), fs, timestamps_sec, n_sub)."""
    z = np.load(npz_path)
    if "magnitude" not in z:
        raise KeyError(f"{npz_path}: no 'magnitude' array (is this a feitcsi_parse.py .npz?)")
    sig = collapse_magnitude(z["magnitude"])
    ts = z["timestamps"] if "timestamps" in z else np.arange(sig.shape[0])
    fs = estimate_fs(ts)
    ts = np.asarray(ts, dtype=np.float64)
    # timestamps are microseconds (consistent with feitcsi_parse.py); seconds from start:
    t_sec = (ts - ts[0]) / 1e6
    return {"sig": sig, "fs": fs, "t_sec": t_sec, "n_sub": sig.shape[1]}


def labels_from_intervals(t_sec, n_frames, intervals):
    """Per-frame labels: 1 if frame time falls in any [start,end] interval (sec)."""
    y = np.zeros(n_frames, dtype=np.int64)
    for s, e in (intervals or []):
        y[(t_sec >= s) & (t_sec <= e)] = 1
    return y


# --- Preprocessing -----------------------------------------------------------

def denoise(sig, fs, lp_hz):
    """Low-pass each subcarrier's time series to suppress RF noise. Falls live in
    the CSI amplitude envelope below ~lp_hz. Zero-phase Butterworth if scipy is
    available, else a centered moving average."""
    nyq = fs / 2.0
    if lp_hz is None or lp_hz <= 0 or lp_hz >= nyq:
        return sig
    if _HAVE_SCIPY:
        sos = butter(4, lp_hz / nyq, btype="low", output="sos")
        return sosfiltfilt(sos, sig, axis=0)
    win = max(3, int(round(fs / lp_hz)) | 1)  # odd
    k = np.ones(win) / win
    pad = sig.copy()
    out = np.empty_like(sig)
    for s in range(sig.shape[1]):
        out[:, s] = np.convolve(np.pad(pad[:, s], (win, win), mode="edge"), k, mode="same")[win:-win]
    return out


def remove_static(sig):
    """Subtract the per-subcarrier temporal mean: drops the static multipath from
    walls/furniture, keeps motion-induced dynamics."""
    return sig - sig.mean(axis=0, keepdims=True)


def normalize(sig):
    """Z-score each subcarrier over time so amplitude scale doesn't dominate."""
    mu = sig.mean(axis=0, keepdims=True)
    sd = sig.std(axis=0, keepdims=True)
    sd[sd < 1e-9] = 1.0
    return (sig - mu) / sd


def preprocess(sig, fs, lp_hz=30.0, do_normalize=True):
    sig = denoise(sig, fs, lp_hz)
    sig = remove_static(sig)
    if do_normalize:
        sig = normalize(sig)
    return sig


# --- Windowing ---------------------------------------------------------------

def make_windows(sig, frame_labels, fs, win_sec, hop_sec, fall_thresh=0.5):
    """Slide a window over (F, Ns). A window is a fall if >= fall_thresh of its
    frames are labeled fall. Returns windows (N, W, Ns) and y (N,)."""
    W = max(2, int(round(win_sec * fs)))
    hop = max(1, int(round(hop_sec * fs)))
    F, Ns = sig.shape
    wins, ys = [], []
    for start in range(0, max(1, F - W + 1), hop):
        w = sig[start:start + W]
        if w.shape[0] < W:
            break
        lab = frame_labels[start:start + W]
        wins.append(w)
        ys.append(1 if lab.mean() >= fall_thresh else 0)
    if not wins:
        return np.empty((0, W, Ns)), np.empty((0,), dtype=np.int64)
    return np.asarray(wins), np.asarray(ys, dtype=np.int64)


# --- Features ----------------------------------------------------------------

def _spectral(m, fs):
    """Spectral features of the subcarrier-mean signal m (W,)."""
    m = m - m.mean()
    W = m.shape[0]
    P = np.abs(np.fft.rfft(m)) ** 2
    f = np.fft.rfftfreq(W, d=1.0 / fs)
    tot = P.sum()
    if tot <= 1e-12:
        return [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    p = P / tot
    bands = [(0.5, 3.0), (3.0, 8.0), (8.0, 20.0)]
    band_e = [p[(f >= lo) & (f < hi)].sum() for lo, hi in bands]
    centroid = float((f * p).sum())
    ent = float(-(p[p > 0] * np.log(p[p > 0])).sum())
    dom = float(f[np.argmax(P)])
    return band_e + [centroid, ent, dom]


def _skew_kurt(x):
    sd = x.std()
    if sd < 1e-9:
        return 0.0, 0.0
    z = (x - x.mean()) / sd
    return float((z ** 3).mean()), float((z ** 4).mean() - 3.0)


FEATURE_NAMES = (
    ["sc_std_mean", "sc_std_std", "sc_std_max",
     "sc_ptp_mean", "sc_ptp_std", "sc_ptp_max",
     "sc_mad_mean", "sc_mad_std", "sc_mad_max",
     "m_var", "m_ptp", "m_mad", "m_zcr", "m_skew", "m_kurt",
     "band_0.5_3", "band_3_8", "band_8_20", "spec_centroid", "spec_entropy", "dom_freq",
     "xsub_corr", "energy_var", "energy_ptp"]
)


def extract_features(windows, fs):
    """windows (N, W, Ns) -> X (N, D). Vectorized per window."""
    N, W, Ns = windows.shape
    X = np.zeros((N, len(FEATURE_NAMES)), dtype=np.float64)
    for i in range(N):
        w = windows[i]                                  # (W, Ns)
        sc_std = w.std(axis=0)                          # (Ns,)
        sc_ptp = w.max(axis=0) - w.min(axis=0)
        sc_mad = np.abs(np.diff(w, axis=0)).mean(axis=0) if W > 1 else np.zeros(Ns)
        m = w.mean(axis=1)                              # (W,) subcarrier-mean signal
        d = np.diff(m) if W > 1 else np.zeros(1)
        m_mad = np.abs(d).max() if d.size else 0.0
        m_zcr = float(np.mean(np.abs(np.diff(np.signbit(m - m.mean()))) > 0)) if W > 2 else 0.0
        skew, kurt = _skew_kurt(m)
        spec = _spectral(m, fs)
        # cross-subcarrier correlation (spatial pattern); falls disrupt it
        if Ns > 1 and W > 2:
            c = np.corrcoef(w.T)
            iu = np.triu_indices(Ns, k=1)
            cc = c[iu]
            xcorr = float(np.nanmean(cc)) if cc.size else 0.0
        else:
            xcorr = 0.0
        e = w.sum(axis=1)                               # per-frame total energy (W,)
        X[i] = [
            sc_std.mean(), sc_std.std(), sc_std.max(),
            sc_ptp.mean(), sc_ptp.std(), sc_ptp.max(),
            sc_mad.mean(), sc_mad.std(), sc_mad.max(),
            m.var(), m.max() - m.min(), m_mad, m_zcr, skew, kurt,
            *spec,
            xcorr, e.var(), e.max() - e.min(),
        ]
    return np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)


# --- Model & evaluation ------------------------------------------------------

def train_evaluate(X, y, groups, seed=0, plot_path=None, verbose=True):
    """Random Forest with subject-wise CV. Returns a metrics dict."""
    n_groups = len(set(groups.tolist()))
    if n_groups >= 3 and len(set(y.tolist())) > 1:
        n_splits = min(5, n_groups)
        cv = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        splitter = cv.split(X, y, groups)
        cv_name = f"StratifiedGroupKFold(n_splits={n_splits}, by subject/trial)"
    else:
        if verbose:
            print("[warn] <3 groups or single class: falling back to StratifiedKFold "
                  "(windows from one fall may leak across folds — metrics optimistic)",
                  file=sys.stderr)
        cv = StratifiedKFold(n_splits=min(5, max(2, int(np.bincount(y).min()))),
                             shuffle=True, random_state=seed)
        splitter = cv.split(X, y)
        cv_name = "StratifiedKFold (NOT group-safe)"

    clf = RandomForestClassifier(n_estimators=300, class_weight="balanced_subsample",
                                 random_state=seed, n_jobs=-1)
    oof_true, oof_pred, oof_proba = [], [], []
    for tr, te in splitter:
        clf.fit(X[tr], y[tr])
        pred = clf.predict(X[te])
        oof_true.append(y[te])
        oof_pred.append(pred)
        if hasattr(clf, "predict_proba") and set(y[tr].tolist()) > {0}:
            oof_proba.append(clf.predict_proba(X[te])[:, 1])
        else:
            oof_proba.append(np.zeros(len(te)))

    oof_true = np.concatenate(oof_true)
    oof_pred = np.concatenate(oof_pred)
    oof_proba = np.concatenate(oof_proba)

    cm = confusion_matrix(oof_true, oof_pred, labels=[0, 1])
    try:
        auc = roc_auc_score(oof_true, oof_proba)
    except ValueError:
        auc = float("nan")

    if verbose:
        print(f"\nCV scheme: {cv_name}")
        print(f"Windows: {len(y)}  (fall={int(y.sum())}, non-fall={int((y==0).sum())})")
        print(f"Groups (subjects/trials): {n_groups}")
        print("\nOut-of-fold classification report:")
        print(classification_report(oof_true, oof_pred, target_names=["non-fall", "fall"],
                                    digits=3, zero_division=0))
        print("Confusion matrix (rows=true, cols=pred):")
        print(f"            pred_non-fall  pred_fall")
        print(f"  non-fall      {cm[0,0]:8d}  {cm[0,1]:9d}")
        print(f"  fall          {cm[1,0]:8d}  {cm[1,1]:9d}")
        print(f"\nROC-AUC (out-of-fold): {auc:.3f}")
        tn, fp, fn, tp = cm.ravel()
        recall = tp / (tp + fn) if (tp + fn) else float("nan")
        precision = tp / (tp + fp) if (tp + fp) else float("nan")
        print(f"Fall recall (sensitivity): {recall:.3f}   <- missing a fall is the worst error")
        print(f"Fall precision:            {precision:.3f}   <- low precision = alarm fatigue")

        clf.fit(X, y)
        imp = sorted(zip(FEATURE_NAMES, clf.feature_importances_), key=lambda t: -t[1])[:10]
        print("\nTop features (RF importance, full-data fit):")
        for name, val in imp:
            print(f"  {val:.3f}  {name}")

    if plot_path and _HAVE_MPL:
        fig, ax = plt.subplots(1, 2, figsize=(10, 4))
        ax[0].imshow(cm, cmap="Blues")
        ax[0].set_title("Confusion matrix (OOF)")
        ax[0].set_xlabel("predicted"); ax[0].set_ylabel("true")
        for r in range(2):
            for c in range(2):
                ax[0].text(c, r, str(cm[r, c]), ha="center", va="center",
                           color="black", fontsize=14)
        fpr = np.linspace(0, 1, 100)
        ax[1].plot([0, 1], [0, 1], "k--", lw=1)
        ax[1].set_title(f"ROC (AUC={auc:.3f})"); ax[1].set_xlabel("FPR"); ax[1].set_ylabel("TPR")
        try:
            from sklearn.metrics import roc_curve
            fpr_t, tpr_t, _ = roc_curve(oof_true, oof_proba)
            ax[1].plot(fpr_t, tpr_t, lw=2)
        except Exception:
            pass
        fig.tight_layout()
        _dir = os.path.dirname(plot_path)
        if _dir:
            os.makedirs(_dir, exist_ok=True)
        fig.savefig(plot_path, dpi=110)
        print(f"\nsaved plot -> {plot_path}")

    return {"auc": auc, "confusion": cm, "recall": recall, "precision": precision}


# --- Synthetic demo ----------------------------------------------------------

def gen_demo(n_subjects=6, duration_sec=30, fs=200, n_falls=3, n_sub=52, seed=0):
    """Synthetic multi-subject CSI. Normal = calm quasi-periodic drift + noise.
    Fall = fast high-Doppler transient (~0.8s) + baseline step + post-fall calm.
    Returns list of dicts: sig (F,Ns), frame_labels (F,), fs, group."""
    rng = np.random.default_rng(seed)
    F = int(duration_sec * fs)
    t = np.arange(F) / fs
    sc = np.arange(n_sub)
    datasets = []
    for g in range(n_subjects):
        spatial = 1.0 + 0.3 * np.sin(2 * np.pi * sc / n_sub)      # (Ns,) baseline profile
        sig = np.tile(spatial, (F, 1))
        labels = np.zeros(F, dtype=np.int64)
        # normal activity: slow drift, per-subcarrier phase
        f_breath = rng.uniform(0.3, 2.0)
        phase = rng.uniform(0, 2 * np.pi, n_sub)
        sig += 0.06 * np.sin(2 * np.pi * f_breath * t[:, None] + phase[None, :])
        sig += 0.02 * rng.standard_normal((F, n_sub))
        # place n_falls events, spaced out
        seg = F // (n_falls + 1)
        for k in range(n_falls):
            t0 = int(seg * (k + 1) + rng.uniform(-seg * 0.2, seg * 0.2))
            t0 = max(10, min(F - int(1.2 * fs), t0))
            dur = rng.uniform(0.6, 1.0)
            n_ev = int(dur * fs)
            tt = np.arange(n_ev) / fs
            env = np.exp(-tt / (dur / 3.0)) * (1 - np.exp(-tt / 0.05))   # rise+decay
            f_dop = rng.uniform(8, 15)                                    # fast motion
            dop = env[:, None] * np.sin(2 * np.pi * f_dop * tt[:, None] + phase[None, :])
            sig[t0:t0 + n_ev] += 0.9 * dop
            sig[t0:t0 + n_ev] += 0.4 * env[:, None]                       # baseline shift
            labels[t0:t0 + n_ev] = 1
            # post-fall stillness for ~1.5s
            still = slice(t0 + n_ev, min(F, t0 + n_ev + int(1.5 * fs)))
            sig[still] = np.tile(spatial + 0.5, (still.stop - still.start, 1)) \
                + 0.01 * rng.standard_normal((still.stop - still.start, n_sub))
        datasets.append({"sig": sig, "frame_labels": labels, "fs": fs, "group": g})
    return datasets


# --- Dataset assembly --------------------------------------------------------

def build_dataset(signals, labels_list, groups, fs_list, win_sec, hop_sec,
                  lp_hz, do_normalize, fall_thresh):
    allX, ally, allg = [], [], []
    for sig, lab, g, fs in zip(signals, labels_list, groups, fs_list):
        sig = preprocess(sig, fs, lp_hz=lp_hz, do_normalize=do_normalize)
        wins, ys = make_windows(sig, lab, fs, win_sec, hop_sec, fall_thresh)
        if len(wins) == 0:
            continue
        feats = extract_features(wins, fs)
        allX.append(feats); ally.append(ys); allg.append(np.full(len(ys), g))
    if not allX:
        raise ValueError("no windows produced — check capture length vs window size")
    return np.vstack(allX), np.concatenate(ally), np.concatenate(allg)


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Baseline Wi-Fi CSI fall detection over FeitCSI captures.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__.split("Requires:")[0])
    ap.add_argument("--npz", nargs="+", help="parser .npz capture(s)")
    ap.add_argument("--labels", help="JSON: {npz: [[start_sec,end_sec],...]} or a plain list")
    ap.add_argument("--demo", action="store_true", help="run on synthetic labeled data")
    ap.add_argument("--win-sec", type=float, default=1.5)
    ap.add_argument("--hop-sec", type=float, default=0.5)
    ap.add_argument("--lp-hz", type=float, default=30.0, help="denoise low-pass cutoff (0=off)")
    ap.add_argument("--no-normalize", action="store_true")
    ap.add_argument("--fall-thresh", type=float, default=0.5,
                    help="fraction of fall frames for a window to count as fall")
    ap.add_argument("--fs", type=float, default=None, help="override sampling rate (Hz)")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--plot", help="write confusion-matrix/ROC PNG to this path")
    ap.add_argument("--save-model", help="pickle the full-data model to this path")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)

    if not _HAVE_SCIPY and args.verbose:
        print("[note] scipy not found — using moving-average denoise", file=sys.stderr)

    if args.demo:
        print("=== DEMO MODE: synthetic labeled multi-subject CSI ===")
        demo = gen_demo(seed=args.seed)
        signals = [d["sig"] for d in demo]
        labels = [d["frame_labels"] for d in demo]
        groups = [d["group"] for d in demo]
        fs_list = [args.fs or d["fs"] for d in demo]
        print(f"generated {len(demo)} subjects x {demo[0]['sig'].shape[0]} frames "
              f"@ {fs_list[0]:.0f} Hz, {int(labels[0].sum())}+ fall frames each")
    elif args.npz:
        signals, labels, groups, fs_list = [], [], [], []
        lab_map = {}
        if args.labels:
            with open(args.labels) as fh:
                raw = json.load(fh)
            if isinstance(raw, dict):
                lab_map = raw
            elif len(args.npz) == 1 and isinstance(raw, list):
                lab_map = {os.path.basename(args.npz[0]): raw, args.npz[0]: raw}
        for i, path in enumerate(args.npz):
            cap = load_capture(path)
            fs = args.fs or cap["fs"]
            key = path if path in lab_map else os.path.basename(path)
            intervals = lab_map.get(key, [])
            frame_lab = labels_from_intervals(cap["t_sec"], cap["sig"].shape[0], intervals)
            if args.verbose:
                print(f"  {path}: {cap['sig'].shape[0]} frames, fs~{fs:.0f} Hz, "
                      f"{int(frame_lab.sum())} fall frames, {cap['n_sub']} subcarriers")
            signals.append(cap["sig"]); labels.append(frame_lab)
            groups.append(i); fs_list.append(fs)
        if sum(l.sum() for l in labels) == 0:
            print("[warn] no fall labels found — provide --labels with fall intervals",
                  file=sys.stderr)
    else:
        ap.error("provide --demo, or --npz (with --labels)")

    X, y, g = build_dataset(signals, labels, groups, fs_list,
                            args.win_sec, args.hop_sec, args.lp_hz,
                            not args.no_normalize, args.fall_thresh)
    if args.verbose:
        print(f"feature matrix X={X.shape}, fall windows={int(y.sum())}/{len(y)}")

    metrics = train_evaluate(X, y, g, seed=args.seed, plot_path=args.plot, verbose=True)

    if args.save_model:
        import pickle
        clf = RandomForestClassifier(n_estimators=300, class_weight="balanced_subsample",
                                     random_state=args.seed, n_jobs=-1)
        clf.fit(X, y)
        with open(args.save_model, "wb") as fh:
            pickle.dump({"model": clf, "feature_names": FEATURE_NAMES,
                         "win_sec": args.win_sec, "hop_sec": args.hop_sec,
                         "lp_hz": args.lp_hz, "normalize": not args.no_normalize}, fh)
        print(f"saved model -> {args.save_model}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
