/*
 * FeitCSI is the tool for extracting CSI information from supported intel NICs.
 * Copyright (C) 2023-2025 Miroslav Hutar.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef WATERFALL_PLOT_H
#define WATERFALL_PLOT_H

#include <gtkmm.h>
#include <deque>
#include <vector>
#include <mutex>
#include <string>
#include <cstdint>

// Scrolling spectrogram of CSI amplitude: X = subcarrier, Y = time (newest at
// the bottom), color = magnitude. Each frame is averaged across RX/TX pairs so
// a frame becomes one row of numSubCarriers values.
class WaterfallPlot : public Gtk::DrawingArea
{
public:
    WaterfallPlot();
    void init(Glib::RefPtr<Gtk::Box> box);
    void addFrame(const std::vector<double> &magnitude, uint32_t numSubCarriers);
    std::string title = "CSI amplitude waterfall";

private:
    static const size_t MAX_ROWS = 300;

    std::deque<std::vector<float>> rows;
    std::mutex rowsMutex;

    void colormap(float t, double &r, double &g, double &b);
    bool on_draw(const Cairo::RefPtr<Cairo::Context> &cr);
};

#endif
