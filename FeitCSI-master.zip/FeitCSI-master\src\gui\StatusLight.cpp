/*
 * FeitCSI is the tool for extracting CSI information from supported intel NICs.
 * Copyright (C) 2023-2025 Miroslav Hutar.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "gui/StatusLight.h"

#include <cmath>

StatusLight::StatusLight()
{
    signal_draw().connect(sigc::mem_fun(*this, &StatusLight::on_draw));
    set_size_request(-1, 36);
}

void StatusLight::init(Glib::RefPtr<Gtk::Box> box)
{
    box->pack_start(*this, false, false);
    show();
}

void StatusLight::setState(State newState, const std::string &text)
{
    bool changed = (newState != this->state) || (!text.empty() && text != this->label);
    this->state = newState;
    if (!text.empty())
    {
        this->label = text;
    }
    if (changed)
    {
        queue_draw();
    }
}

bool StatusLight::on_draw(const Cairo::RefPtr<Cairo::Context> &cr)
{
    Gtk::Allocation allocation = get_allocation();
    const int width = allocation.get_width();
    const int height = allocation.get_height();

    // Background bar
    cr->set_source_rgb(0.95, 0.95, 0.95);
    cr->paint();

    double radius = (height - 14) / 2.0;
    if (radius < 6)
    {
        radius = 6;
    }
    const double cx = 10 + radius;
    const double cy = height / 2.0;

    double r = 0.6, g = 0.6, b = 0.6;
    switch (this->state)
    {
    case OK:
        r = 0.10; g = 0.70; b = 0.10;
        break;
    case WARN:
        r = 0.90; g = 0.75; b = 0.00;
        break;
    case ERR:
        r = 0.85; g = 0.10; b = 0.10;
        break;
    default:
        r = 0.60; g = 0.60; b = 0.60;
        break;
    }

    cr->set_source_rgb(r, g, b);
    cr->arc(cx, cy, radius, 0, 2 * M_PI);
    cr->fill();

    cr->set_source_rgb(0.0, 0.0, 0.0);
    cr->set_font_size(14);
    cr->move_to(cx + radius + 12, cy + 5);
    cr->show_text(this->label);

    (void)width;
    return true;
}
