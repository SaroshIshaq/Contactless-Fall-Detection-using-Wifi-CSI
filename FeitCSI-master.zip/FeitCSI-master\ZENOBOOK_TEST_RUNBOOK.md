# Zenbook Test Runbook — FeitCSI + FYP Features

Goal: on the **Asus Zenbook 14 OLED under native Linux**, verify (1) the NIC can
extract CSI at all, (2) the **passive target-device capture** approach your FYP
depends on actually works, and (3) the four new features (MAC filter, GUI field,
waterfall, status light) behave correctly.

> **WSL cannot do any of this.** WSL has no Intel NIC, no monitor mode, and no
> `csi_enabled` debugfs. WSL was compile-check only. Everything below runs on
> the Zenbook booted into real Linux.

> **First time on the Zenbook?** Complete `UBUNTU_QODER_SETUP.md` first (native
> Ubuntu install + Qoder + toolchain + the `csi_enabled` hardware gate). This
> runbook assumes that's already done.

Work top to bottom. Each phase has a **gate**: if it fails, stop and fix before
continuing — later phases assume earlier ones passed.

---

## Phase 0 — Prerequisites & hardware check (before building)

**0.1 Boot native Linux.** Ubuntu 22.04 or 24.04 LTS is the safe choice
(matches the WSL build env). Dual-boot or a live USB both work; a live USB is
fine for testing but you'll re-install deps each boot.

**0.2 Confirm the NIC model.** FeitCSI officially supports Intel **AX200 /
AX210** (newer Intel NICs "high possibility" supported). Your "2x10" NIC is
unverified — this step settles it.

```bash
lspci -nnk | grep -iA3 network
```

- **Expected:** an Intel Wi-Fi 6/6E device (AX200/AX210/AX211). Note the exact
  model.
- **If it's an AX211:** it's a "CNVio2" part — usually still works, but record
  it; if CSI fails later, the NIC is the prime suspect.
- **If it's not Intel** (e.g. MediaTek/Realtek): FeitCSI will not work. Stop —
  you need a supported Intel NIC.

**0.3 Confirm the iwlwifi driver is bound and debugfs exists.**

```bash
sudo modprobe iwlwifi
ls -d /sys/kernel/debug/iwlwifi/*/
```

- **Expected:** at least one directory like `/sys/kernel/debug/iwlwifi/0000:00:14.3/`.
- **If `/sys/kernel/debug/iwlwifi` is missing:** debugfs isn't mounted or the
  kernel lacks iwlwifi debugfs. Try `sudo mount -t debugfs none /sys/kernel/debug`
  then re-list. FeitCSI throws *"Did you compile iwlwifi with debugfs enabled?"*
  if this is absent.

**0.4 Confirm the CSI knob exists — this is the make-or-break hardware check.**

```bash
ls /sys/kernel/debug/iwlwifi/*/iwlmvm/csi_enabled
```

- **Expected:** the path prints (file exists). This is exactly the file FeitCSI
  writes `1`/`0` to (`WiFiCsiController.cpp:239`).
- **If "No such file":** your NIC/driver combo does not expose CSI. FeitCSI
  would throw *"Failed to enable csi measurement. Maybe device not support it."*
  **Stop here** — the project needs a CSI-capable NIC (AX200/AX210) before any
  of the feature testing matters.

> **Phase 0 gate:** `csi_enabled` file exists. If not, do not proceed.

---

## Phase 1 — Build FeitCSI on the Zenbook

**1.1 Install build dependencies** (same set used in WSL):

```bash
sudo apt update
sudo apt install -y build-essential pkg-config \
  libgtkmm-3.0-dev libnl-3-dev libnl-genl-3-dev libiw-dev libpcap-dev
```

**1.2 Get the source onto the Zenbook.** Copy the whole `FeitCSI-master` folder
(this file included) via USB, `scp`, or a git clone of your edited tree.

**1.3 Build:**

```bash
cd FeitCSI-master
make
```

- **Expected:** compiles and links `bin/app` (~5.4 MB). A pre-existing harmless
  `fgets` warning in `WiFIController.cpp` may appear — ignore it.
- **If a header is missing:** re-run 1.1; you likely skipped a `-dev` package.

**1.4 Sanity-check the binary:**

```bash
./bin/app --help | head -40
```

- **Expected:** the argp help lists all options including your new
  `--filter-mac` / `-F`. Confirm `-F` appears — that proves Feature 1 is in the
  build.

> **Phase 1 gate:** `bin/app` exists and `--help` shows `-F`.

---

## Phase 2 — Baseline CSI smoke test (single NIC, self inject+measure)

This proves the CSI pipeline works end-to-end **without needing any second
device**. FeitCSI's `measureinject` mode makes the one NIC both inject a frame
and capture its own CSI.

**2.1 Find a clean 2.4 GHz channel.** Channel 1 = 2412 MHz is the default and
fine for a smoke test.

**2.2 Run it (as root — monitor mode + debugfs require it):**

```bash
sudo ./bin/app -i measureinject -f 2412 -w 20 -v -o /tmp/smoke.dat
```

Flag reference (confirmed from source):
- `-i measureinject` — inject + measure on the same NIC.
- `-f 2412` — frequency in MHz (**required**).
- `-w 20` — channel width 20/40/80/160 (**required**; the error message says
  "-b" but the real check is frequency + bandwidth).
- `-v` — verbose (prints each frame's detail, including the **Source MAC** line
  Feature 1 added).
- `-o /tmp/smoke.dat` — output file (default is `FeitCSI_<timestamp>.dat`).

Let it run ~10 s, then `Ctrl-C`.

- **Expected:** verbose log shows CSI frames being decoded; `/tmp/smoke.dat`
  grows (each record = 272-byte `RawHeaderData` header + CSI payload).
- **If it throws on interface setup:** FeitCSI removes your existing wifi
  interfaces and creates `FeitCSImon` + `FeitCSIap`. Make sure nothing else is
  using wifi and you ran with `sudo`.
- **If "Failed to enable csi measurement":** back to Phase 0.4 — NIC issue.

**2.3 Restore networking after the test.** FeitCSI kills `NetworkManager` and
`wpa_supplicant` and replaces your interfaces while running. After it exits, if
wifi doesn't come back:

```bash
sudo systemctl restart NetworkManager
# if still down: reboot
```

> **Phase 2 gate:** verbose output shows decoded CSI frames and the `.dat` file
> is non-empty. The hardware + build + CSI pipeline all work.

---

## Phase 3 — THE critical test: passive capture of your transmitter

**This is the riskiest assumption in your whole FYP.** Your plan is: Zenbook
sniffs passively while a *separate* transmitter (phone / 2nd laptop / ESP32)
stays associated with the router and transmits steadily; you filter by the
transmitter's `srcMac`. That only works if **Intel iwlwifi attaches CSI to
passively overheard third-party frames**, not just frames in an active RX to the
Zenbook. Phase 2 (self-inject) does *not* prove this. Test it explicitly.

**3.1 Set up the transmitter.**
- Pick any Wi-Fi device you own. Connect it to your router normally.
- Make it transmit **steadily and fast** (CSI rate ≈ packet rate; you need
  100–1000 Hz for falls, default ~10 Hz is far too slow). On a 2nd Linux laptop
  or the router's network:
  ```bash
  # UDP flood to the router (or any host) to drive packet rate up
  iperf3 -c <router-ip> -u -b 50M -t 60
  # or a fast ping
  ping -i 0.005 <router-ip>
  ```
  A phone works too — start a large download / video call.

**3.2 Find the router's channel** (do this *before* launching FeitCSI, which
takes over the radio). Easiest:

```bash
nmcli -f SSID,CHAN,FREQ dev wifi list
```

Note the router's channel and frequency (e.g. channel 6 → 2437 MHz, or a 5 GHz
channel → its MHz value).

**3.3 Capture passively on the router's channel — NO inject, NO filter yet.**
Verbose mode prints the `srcMac` of every decoded frame so you can *discover*
the transmitter's real MAC from live traffic (avoids phone MAC-randomization
guesswork).

```bash
sudo ./bin/app -i measure -f <router-freq-MHz> -w 20 -v -o /tmp/passive.dat
```

Watch the `Source MAC: xx:xx:...` lines.

- **Expected (best case):** you see frames whose `srcMac` equals your
  transmitter's MAC. **If so — the passive approach works.** Record that MAC;
  it's your `-F` target.
- **If you only ever see the Zenbook's own MAC or the router's beacon MAC, never
  the transmitter's data frames:** iwlwifi is likely only reporting CSI for
  frames it actively decodes as the receiver, not arbitrary overheard frames.
  See **3.5 fallback**.

**3.4 Identify the transmitter's MAC reliably.** From the verbose `Source MAC`
lines in 3.3, pick the one that appears at your transmitter's packet rate.
Cross-check on the transmitter itself (`ip link show wlan0` → `link/ether`, or
the router's client list). Beware phone **MAC randomization** (per-network
private address) — use the address actually seen on air, or disable
randomization for that network.

**3.5 Fallback if passive capture does NOT yield the transmitter's CSI.**
Don't panic — you have options, in order of preference:
1. **Make the Zenbook the receiver in the link.** Have the transmitter send
   *to the Zenbook* (e.g. `iperf3` from transmitter → Zenbook's IP) instead of
   to the router. Frames addressed to the Zenbook are actively decoded, so CSI
   is far more likely. This still matches "one specific device's CSI."
2. **Use a second CSI-capable Intel NIC** as a dedicated inject↔measure pair
   (the classic FeitCSI two-NIC setup). More hardware, but guaranteed CSI.
3. **Re-scope** to environment/activity CSI (presence/motion in the channel)
   rather than per-device — still valid for fall detection, just a different
   framing.

> **Phase 3 gate:** you can see, in verbose output, CSI frames carrying a
> *specific remote device's* `srcMac`. Write down which approach (3.3 passive or
> 3.5 fallback) produced it — everything after assumes you have a working target
> MAC and capture command.

---

## Phase 4 — Test the four new features

Use the working capture command from Phase 3 as the base for each test.

### Feature 1 — Target-MAC filter (`-F`) — CLI

```bash
sudo ./bin/app -i measure -f <freq> -w 20 -v -F <transmitter-MAC> -o /tmp/filtered.dat
```

- **Expected:** verbose `Source MAC` lines now show **only** `<transmitter-MAC>`.
  All other frames are dropped (and, thanks to the leak fix, freed — memory
  stays flat over a long run; check with `top`/`htop` RES on the `app` process).
- **Compare:** run once without `-F` and once with; the filtered run should keep
  strictly fewer frames, all from the target.
- **Memory-leak check (Feature 1 also fixed this):** let the filtered run go
  60+ s while watching RES in `htop`. It should plateau, not climb steadily.

### Feature 2 — GUI target-MAC field

```bash
sudo ./bin/app -x -f <freq> -w 20
```

- The GUI opens. In the left settings panel, the new **"Target MAC filter:"**
  entry sits at the bottom of the grid (row 18), placeholder
  `xx:xx:xx:xx:xx:xx (empty = all)`.
- **Test empty:** leave blank → no filtering (all frames kept).
- **Test valid:** type the transmitter MAC → filtering engages; only target
  frames plot.
- **Test invalid:** type `zz:zz` or `123` → an error message appears in the
  error area ("Target MAC filter: invalid format…") and filtering stays off.
- **Test sensitivity:** start measuring → the field should grey out
  (non-editable) while measuring, re-enable when stopped.

### Feature 3 — Waterfall heatmap

Visible in both GUI (`-x`) and CLI-with-plot (`-p`):

```bash
sudo ./bin/app -x -p -f <freq> -w 20 -F <transmitter-MAC>
```

- **Expected:** below the amplitude/phase line plots, a **scrolling heatmap**
  (subcarrier index × time) renders. Columns = subcarriers, rows scroll with
  time, color = magnitude (blue → cyan → green → yellow → red "jet" colormap).
- **Live check:** wave a hand / walk between transmitter and Zenbook — the
  waterfall pattern should visibly shift. This is the signal you'll feed the
  fall detector.
- **If blank:** confirm frames are actually arriving (status light should be
  green — see Feature 4) and that you're capturing the target (Phase 3).

### Feature 4 — Capture-health status light

Top of the plot panel in the GUI. Color meaning (from `MainController::updateStatus`,
refreshed every 200 ms):

| Color | Meaning | When you should see it |
|-------|---------|------------------------|
| **Grey** | Idle — not measuring | Before you start, or after stop |
| **Green** | Target CSI received < 1 s ago | Healthy capture of your `-F` target |
| **Yellow** | CSI seen but **no target match** < 1 s | Capturing, but wrong/no MAC — filter mismatch |
| **Red** | Error, or measuring but **no CSI** at all | NIC/CSI failure, wrong channel, nothing transmitting |

- **Test transitions:** start measuring with no transmitter → red. Begin
  transmitter traffic on the right channel → green. Set `-F` to a bogus MAC →
  yellow (frames arrive but none match). Kill the transmitter → back to red
  within ~1 s.

> **Phase 4 gate:** `-F` keeps only the target; GUI field validates and filters;
> waterfall scrolls and responds to movement; status light transitions
> grey/green/yellow/red as described.

---

## Phase 5 — Real data collection for the FYP

Once Phases 0–4 pass, collect the dataset you'll actually train on.

**5.1 Drive the packet rate up.** Fall detection needs ~100–1000 Hz CSI.
Default ~10 Hz is useless. The CSI rate ≈ transmitter packet rate, so flood:
`iperf3 -u -b 50M+` or `ping -i 0.002`. Verify the achieved rate by counting
verbose frames per second, or by file growth.

**5.2 Capture command (target-filtered, to a named file):**

```bash
sudo ./bin/app -i measure -f <freq> -w 20 -F <transmitter-MAC> \
  -o captures/fall_01.dat
```

**5.3 Output format & parsing (Feature 5 — built).** Each `.dat` record =
272-byte `RawHeaderData` header + CSI payload (raw binary, little-endian; each
sample = int16 real + int16 imag, ordered rx → tx → subcarrier). Use
`feitcsi_parse.py` (repo root) to convert captures for ML:

```bash
# Inspect a capture: frame count, shape, format, MACs, estimated CSI rate
python3 feitcsi_parse.py captures/fall_01.dat --info

# Convert to NumPy .npz (default) + per-frame metadata CSV
python3 feitcsi_parse.py captures/fall_01.dat --meta-csv

# Also emit a tidy long-format CSV (one row per frame/rx/tx/subcarrier; large)
python3 feitcsi_parse.py captures/fall_01.dat --csv

# Drop pilot subcarriers (uses the format/width tables from Csi.h)
python3 feitcsi_parse.py captures/fall_01.dat --drop-pilots
```

The `.npz` holds `magnitude` / `phase` / `real` / `imag` shaped
`(frames, rx, tx, subcarrier)` plus per-frame metadata (`timestamps`, `src_mac`,
`rssi1/2`, `format_code`, `width_code`, `num_*`). Load it in Python:

```python
import numpy as np
from feitcsi_parse import load_magnitude          # convenience shortcut
mag = load_magnitude("captures/fall_01.dat")      # (frames, rx, tx, subcarrier)
# or full access:
z = np.load("captures/fall_01.npz")
mag, phase, ts = z["magnitude"], z["phase"], z["timestamps"]
```

Ragged captures (channel width changed mid-run) are NaN-padded to the max shape;
`num_subcarriers` per frame tells you the valid region. The parser was validated
by a synthetic round-trip test (`test_feitcsi_parse.py`, 32 checks) but **has not
yet seen a real Zenbook capture** — run `--info` on your first real `.dat` and
confirm the frame count / shape / MAC look sane before trusting a dataset.

**5.4 Environment setup for clean fall data:**
- Fix transmitter and Zenbook positions; mark them on the floor. Consistency
  beats cleverness — the channel should be static except for the human.
- Define the **sensing region** (where the person walks/falls) between the two
  radios. Fresnel-zone disturbance is what you're measuring.
- Record metadata per capture: subject, activity (walk / sit / fall / pickup),
  trial number, transmitter MAC, channel, packet rate, start time.
- Collect **many trials per class**, including false-fall lookalikes (sitting
  down fast, bending, dropping an object) — these are what make a fall detector
  hard and publishable.
- Mind the **legal note**: FeitCSI is unlocked for all bands/power; you are
  responsible for staying within your country's allowed frequencies and power.
  Staying on standard Wi-Fi channels at default power is normally fine.

**5.5 Restore networking** after each session (Phase 2.3).

---

## Phase 6 — From capture to model (baseline fall detection)

Once you have labeled captures, `baseline_fall_detection.py` (repo root) turns
the parser's `.npz` into a trained baseline. It needs **numpy + scikit-learn**
(scipy/matplotlib optional). Install: `sudo apt install python3-sklearn python3-scipy`.

**6.0 Labeling is the prerequisite.** The model is supervised — it needs to know
*when* each fall happened. While collecting (Phase 5), log each fall's start/end
time (watch a synced video, or press a key/timestamp at each event). Convert to
seconds-from-capture-start into a `labels.json`:

```json
{"run1.npz": [[12.3, 13.1], [40.0, 41.2]], "run2.npz": [], "run3.npz": [[5.5, 6.4]]}
```

Each `.npz` is one **group** (subject/trial). Empty list = no falls in that run.

**6.1 Smoke-test the pipeline (no data needed).** Runs on synthetic labeled
multi-subject CSI to prove the plumbing end to end:

```bash
python3 baseline_fall_detection.py --demo --plot demo.png
```

- **Expected:** prints an out-of-fold classification report, confusion matrix,
  ROC-AUC, fall recall/precision, and top feature importances; writes `demo.png`.
  On clean synthetic data AUC is ~0.99 — real data will be much messier.

**6.2 Train on your real captures:**

```bash
# Parse first (Phase 5.3), then train with subject-wise CV
python3 feitcsi_parse.py captures/run1.dat -o captures/run1
python3 feitcsi_parse.py captures/run2.dat -o captures/run2
python3 baseline_fall_detection.py \
  --npz captures/run1.npz captures/run2.npz \
  --labels labels.json -v --plot results.png --save-model fall_rf.pkl
```

**6.3 Read the metrics like a researcher, not an engineer:**
- **CV is subject-wise (grouped)** — windows from one fall never straddle
  train/test. If you see the *"falling back to StratifiedKFold"* warning, you
  gave it < 3 captures, so the score is optimistic (leakage). **Collect several
  subjects/trials** for an honest number. This is the #1 thing examiners check.
- **Class imbalance is normal** (falls are rare). Don't trust accuracy — read
  **fall recall** (sensitivity: did it catch the falls?) and **precision** (alarm
  fatigue). For a fall detector, recall usually matters more; tune the decision
  threshold on the ROC to trade them off.
- **Top features** are usually motion-intensity ones (`sc_ptp_*`, `sc_mad_*`,
  `sc_std_*` = subcarrier peak-to-peak / mean-abs-diff / std) plus `xsub_corr`
  (spatial pattern disruption). That physical story is gold for your writeup.

**6.4 Where to go next** (the baseline is the floor, not the ceiling):
- More subjects, more trials, more fall variants (and lookalikes: sitting fast,
  bending, dropping something) — data beats model tweaks.
- Upgrade the model: a small **CNN on the (subcarrier × time) waterfall image**,
  or an **LSTM/TCN** on the windowed series, compared against this RF baseline.
- If falls are too rare to label, consider an **autoencoder / one-class** anomaly
  approach trained on normal activity only.
- Sanitize **phase** (linear-fit / unwrap) and add it as a second channel — raw
  Intel phase is noisy, which is why the baseline uses magnitude only.

> **Phase 6 gate:** `--demo` runs clean, and training on ≥ 3 labeled captures
> produces a grouped-CV report with non-trivial fall recall. Record the numbers.

---

## Troubleshooting quick table

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| `/sys/kernel/debug/iwlwifi` not found | debugfs not mounted / kernel lacks it | `sudo mount -t debugfs none /sys/kernel/debug`; check Phase 0.3 |
| "Failed to enable csi measurement" | NIC/driver has no `csi_enabled` | Phase 0.4 — need AX200/AX210; NIC unsupported |
| "Fill required arguments -f -b" | missing `-f` or `-w` | add both (`-w` is bandwidth, despite the "-b" text) |
| Interface setup throws | wifi in use / not root | close other wifi apps, run with `sudo` |
| No CSI frames at all | wrong channel/frequency | re-scan router channel (Phase 3.2), match `-f` |
| Frames but never the transmitter's MAC | passive capture limitation | Phase 3.5 fallback (make Zenbook the receiver) |
| `-F` keeps zero frames | MAC mismatch / randomization | verify MAC from verbose `Source MAC` lines, not guesswork |
| Status light stuck red while measuring | nothing transmitting / wrong channel | start transmitter flood, confirm channel |
| Status light yellow | capturing but filter excludes all | check `-F` MAC matches the live `srcMac` |
| Waterfall blank | no accepted frames | confirm green light + target capture first |
| Memory climbs over a long run | (should be fixed) leak | Feature 1 fixed it — if it still climbs, report; check `htop` RES |
| Wifi dead after running | FeitCSI killed NetworkManager | `sudo systemctl restart NetworkManager` or reboot |

---

## Command cheat sheet

```bash
# Hardware gate
ls /sys/kernel/debug/iwlwifi/*/iwlmvm/csi_enabled

# Build
make && ./bin/app --help | grep filter-mac

# Baseline self-test (one NIC)
sudo ./bin/app -i measureinject -f 2412 -w 20 -v -o /tmp/smoke.dat

# Discover transmitter MAC (passive, verbose, no filter)
sudo ./bin/app -i measure -f <router-freq> -w 20 -v -o /tmp/passive.dat

# Target-filtered capture
sudo ./bin/app -i measure -f <freq> -w 20 -F <tx-MAC> -o captures/run.dat

# GUI with all features (field + waterfall + status light)
sudo ./bin/app -x -p -f <freq> -w 20 -F <tx-MAC>

# Parse a capture for ML (inspect, then convert to .npz)
python3 feitcsi_parse.py captures/run.dat --info
python3 feitcsi_parse.py captures/run.dat --meta-csv --drop-pilots

# Restore wifi
sudo systemctl restart NetworkManager
```

---

## Results log (fill in as you go)

| Phase | Gate | Pass/Fail | Notes (NIC model, MACs, channels, rates) |
|-------|------|-----------|-------------------------------------------|
| 0.4 | `csi_enabled` exists | | NIC model: |
| 1 | `bin/app` + `-F` in help | | |
| 2 | self inject+measure decodes CSI | | |
| 3 | passive/fallback sees target srcMac | | approach used: |
| 4.1 | `-F` keeps only target, mem flat | | |
| 4.2 | GUI field validates/filters | | |
| 4.3 | waterfall scrolls, responds to motion | | |
| 4.4 | status light grey/green/yellow/red | | |
| 5 | real capture at target Hz | | achieved rate: |
