/*
 * FeitCSI is the tool for extracting CSI information from supported intel NICs.
 * Copyright (C) 2023-2025 Miroslav Hutar.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "gui/WaterfallPlot.h"

#include <cfloat>
#include <algorithm>

WaterfallPlot::WaterfallPlot()
{
    signal_draw().connect(sigc::mem_fun(*this, &WaterfallPlot::on_draw));
    set_size_request(-1, 220);
}

void WaterfallPlot::init(Glib::RefPtr<Gtk::Box> box)
{
    box->pack_start(*this, true, true);
    show();
}

void WaterfallPlot::addFrame(const std::vector<double> &magnitude, uint32_t numSubCarriers)
{
    if (numSubCarriers == 0 || magnitude.size() < numSubCarriers)
    {
        return;
    }

    // Average each subcarrier across the RX/TX pairs contained in this frame.
    const size_t pairs = magnitude.size() / numSubCarriers;
    std::vector<float> row(numSubCarriers);
    for (uint32_t sc = 0; sc < numSubCarriers; sc++)
    {
        double sum = 0.0;
        for (size_t p = 0; p < pairs; p++)
        {
            sum += magnitude[p * numSubCarriers + sc];
        }
        row[sc] = (float)(sum / (double)pairs);
    }

    {
        std::lock_guard<std::mutex> lock(this->rowsMutex);
        this->rows.push_back(std::move(row));
        while (this->rows.size() > MAX_ROWS)
        {
            this->rows.pop_front();
        }
    }

    queue_draw();
}

// Blue -> cyan -> green -> yellow -> red
void WaterfallPlot::colormap(float t, double &r, double &g, double &b)
{
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;

    static const float anchors[5] = {0.0f, 0.25f, 0.5f, 0.75f, 1.0f};
    static const double colors[5][3] = {
        {0.0, 0.0, 0.5},
        {0.0, 0.5, 1.0},
        {0.0, 1.0, 0.0},
        {1.0, 1.0, 0.0},
        {1.0, 0.0, 0.0},
    };

    int seg = 0;
    while (seg < 3 && t > anchors[seg + 1])
    {
        seg++;
    }
    float span = anchors[seg + 1] - anchors[seg];
    float f = span > 0.0f ? (t - anchors[seg]) / span : 0.0f;
    r = colors[seg][0] + (colors[seg + 1][0] - colors[seg][0]) * f;
    g = colors[seg][1] + (colors[seg + 1][1] - colors[seg][1]) * f;
    b = colors[seg][2] + (colors[seg + 1][2] - colors[seg][2]) * f;
}

bool WaterfallPlot::on_draw(const Cairo::RefPtr<Cairo::Context> &cr)
{
    Gtk::Allocation allocation = get_allocation();
    const int width = allocation.get_width();
    const int height = allocation.get_height();

    cr->set_source_rgb(0.05, 0.05, 0.05);
    cr->paint();

    std::vector<std::vector<float>> snapshot;
    {
        std::lock_guard<std::mutex> lock(this->rowsMutex);
        snapshot.assign(this->rows.begin(), this->rows.end());
    }

    const int nRows = (int)snapshot.size();
    const int nCols = nRows > 0 ? (int)snapshot.back().size() : 0;

    if (nRows > 0 && nCols > 0)
    {
        float mn = FLT_MAX;
        float mx = -FLT_MAX;
        for (const auto &row : snapshot)
        {
            for (float v : row)
            {
                if (v < mn) mn = v;
                if (v > mx) mx = v;
            }
        }
        float range = mx - mn;
        if (range < 1e-6f) range = 1e-6f;

        const int stride = cairo_format_stride_for_width(CAIRO_FORMAT_RGB24, nCols);
        unsigned char *buffer = new unsigned char[(size_t)stride * nRows];

        for (int y = 0; y < nRows; y++)
        {
            const std::vector<float> &row = snapshot[y];
            for (int x = 0; x < nCols; x++)
            {
                float t = (x < (int)row.size()) ? (row[x] - mn) / range : 0.0f;
                double r, g, b;
                colormap(t, r, g, b);
                unsigned char *px = buffer + (size_t)y * stride + x * 4;
                px[0] = (unsigned char)(b * 255); // little-endian RGB24: B,G,R,X
                px[1] = (unsigned char)(g * 255);
                px[2] = (unsigned char)(r * 255);
                px[3] = 255;
            }
        }

        Cairo::RefPtr<Cairo::ImageSurface> surface =
            Cairo::ImageSurface::create(buffer, Cairo::FORMAT_RGB24, nCols, nRows, stride);

        cr->save();
        cr->scale((double)width / nCols, (double)height / nRows);
        Cairo::RefPtr<Cairo::SurfacePattern> pattern = Cairo::SurfacePattern::create(surface);
        pattern->set_filter(Cairo::FILTER_NEAREST);
        cr->set_source(pattern);
        cr->paint();
        cr->restore();

        surface->finish();
        delete[] buffer;
    }

    // Title overlay
    cr->set_source_rgb(1.0, 1.0, 1.0);
    cr->set_font_size(14);
    cr->move_to(8, 18);
    cr->show_text(this->title);

    return true;
}
