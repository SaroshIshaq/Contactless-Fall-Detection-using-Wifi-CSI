# Native Ubuntu + Qoder Setup Checklist (Zenbook)

**Purpose:** get from "code on my Windows box" to "Qoder running natively on the
Zenbook's Ubuntu, with terminal access, ready to let the agent drive runbook
Phases 0–4 on real hardware."

**Why native and not WSL:** WSL has no access to the Intel NIC, monitor mode, or
the `csi_enabled` debugfs — it can only compile. Real CSI capture *requires*
Ubuntu installed directly on the Zenbook. This checklist gets you there; the
actual testing lives in `ZENOBOOK_TEST_RUNBOOK.md`.

> Legend: `[ ]` = do this. Items marked **(agent)** are things I can run for you
> once terminal access is on; everything else needs you.

---

## Part A — Choose the install approach

- [ ] **Recommended: dual-boot Ubuntu alongside Windows.** Keeps Windows for
      planning/editing (your usual workflow) and gives native Linux for capture.
      Downside: reboot to switch; disk partitioning.
- [ ] Alternative: **full Ubuntu install** (wipe Windows). Simplest, but you lose
      the Windows side — only do this if you don't need Windows on the Zenbook.
- [ ] Alternative: **Ubuntu live USB with persistence.** No install; good for a
      first hardware check, but slower and you re-install build deps each boot.
      Fine for Phase 0, awkward for ongoing work.
- [ ] Decide now and note it: ______________

## Part B — Prep on Windows (before touching the Zenbook)

- [ ] **Back up the Zenbook.** Dual-booting resizes partitions — back up anything
      you can't lose first.
- [ ] **Download the Ubuntu ISO** (24.04 LTS recommended; 22.04 also fine) and
      make a bootable USB (e.g. Rufus / balenaEtcher).
- [ ] **Copy the `FeitCSI-master` folder** to a USB stick or cloud/git so you can
      get it onto Ubuntu. (It already contains all features, the parser, the ML
      baseline, the runbook, and this checklist.)
- [ ] **Note your network details:** router SSID + channel/frequency, and the
      transmitter device you'll use. You'll need these for Phase 3.
- [ ] **(Optional but smart) plan Ethernet** for the Zenbook's own internet
      during capture — see Part G. USB-Ethernet adapter works if there's no port.

## Part C — Install Ubuntu on the Zenbook

- [ ] Boot the USB (Asus: usually **Esc** or **F2** at power-on for the boot menu).
- [ ] Run the installer. For dual-boot, choose **"Install Ubuntu alongside
      Windows"** (or manually shrink the Windows partition first).
- [ ] **Secure Boot:** if enabled, Ubuntu will ask to enroll a MOK key for
      third-party drivers — follow the prompts, or disable Secure Boot in BIOS if
      it fights you.
- [ ] Tick **"Install third-party drivers"** (helps with Wi-Fi/firmware).
- [ ] Complete install, reboot into Ubuntu.

## Part D — First boot: verify the hardware (esp. the NIC)

This is "is the Wi-Fi card alive under Linux" — the CSI-specific gate is runbook
Phase 0.

- [ ] `sudo apt update && sudo apt upgrade -y`
- [ ] Confirm Wi-Fi works (connect to your router normally). If the Intel NIC
      isn't recognized: `sudo apt install linux-firmware` then reboot.
- [ ] Identify the NIC and driver:
      ```bash
      lspci -nnk | grep -iA3 network
      ```
      Record the exact model (AX200 / AX210 / AX211 / other): ______________
- [ ] Confirm the iwlwifi driver is bound (the `Kernel driver in use:` line above
      should say `iwlwifi`).
- [ ] **CSI capability gate** (runbook Phase 0.4) — the make-or-break check:
      ```bash
      ls /sys/kernel/debug/iwlwifi/*/iwlmvm/csi_enabled
      ```
      - [ ] File exists → CSI is possible, proceed.
      - [ ] "No such file" → **stop**; the NIC/driver doesn't expose CSI. Tell me
            the `lspci` output and we'll reassess (different NIC, or re-scope).

## Part E — Install Qoder + the build toolchain

- [ ] **Install Qoder.** Download the Linux **.deb** from
      [qoder.com/download](https://qoder.com/download), then:
      ```bash
      sudo apt install ./qoder*.deb        # adjust to the actual filename
      ```
      (A Linux CLI is also offered on the same page if you prefer terminal-only.)
- [ ] **Install FeitCSI build deps** (runbook Phase 1.1):
      ```bash
      sudo apt install -y build-essential pkg-config \
        libgtkmm-3.0-dev libnl-3-dev libnl-genl-3-dev libiw-dev libpcap-dev
      ```
- [ ] **Install the Python ML deps** (parser + baseline):
      ```bash
      sudo apt install -y python3-numpy python3-sklearn python3-scipy
      ```

## Part F — Get the code over and open it in Qoder

- [ ] Copy `FeitCSI-master` onto the Zenbook (USB / scp / git clone), e.g. into
      `~/FeitCSI-master`.
- [ ] **Open that folder in Qoder.**
- [ ] **Enable terminal access for the agent** (set the permission mode so I can
      run shell commands; you'll still approve privileged/sudo ones).
- [ ] Quick sanity build **(agent can do this):**
      ```bash
      cd ~/FeitCSI-master && make && ./bin/app --help | grep filter-mac
      ```
      Expect `bin/app` to build and `-F`/`--filter-mac` to appear.

## Part G — Safety / working agreement (read before any capture)

- [ ] **Ethernet for the Zenbook's own connection** if possible. FeitCSI **kills
      NetworkManager and takes over the Wi-Fi radio** during capture; if the
      machine's session rides on that Wi-Fi it can drop mid-run. Ethernet avoids
      this. (Running Qoder locally on the Zenbook also reduces the risk.)
- [ ] **sudo:** captures need root. I'll ask before running any privileged or
      radio/network-affecting command — expect approval prompts.
- [ ] **After every capture, restore networking:**
      ```bash
      sudo systemctl restart NetworkManager
      ```
- [ ] **Physical setup is yours:** transmitter placement, router channel, the
      sensing area, and being the person who walks/sits/falls for data.
- [ ] **Legal:** FeitCSI is unlocked for all bands/power; stay within your
      country's allowed Wi-Fi frequencies and power (standard channels + default
      power is normally fine).

## Part H — Handoff: kick off the testing

- [ ] Once Parts A–G are done, tell me something like:
      > "Native Ubuntu on the Zenbook, Qoder terminal access on, NIC is
      > `<model>`, `csi_enabled` exists, code in `~/FeitCSI-master`."
- [ ] **(agent)** I'll then drive runbook **Phase 0 → Phase 4** from the
      terminal: hardware confirm → build → `measureinject` smoke test → passive
      capture with `-v` (I'll grep the `srcMac` lines to see if your transmitter
      appears) → `-F` filter test. I'll pause before each capture to tell you
      exactly what physical setup I need (transmitter flooding, router channel),
      and ask before any sudo/radio command.
- [ ] **(you)** For Phase 5 data collection you'll be the subject and log fall
      times; I'll run the captures and then the parse → train pipeline.

---

**Files that go together:**
- `UBUNTU_QODER_SETUP.md` — this checklist (get onto native Ubuntu + Qoder)
- `ZENOBOOK_TEST_RUNBOOK.md` — the actual test procedure (Phases 0–6)
- `feitcsi_parse.py` / `baseline_fall_detection.py` — capture → dataset → model

**The single most important gate:** Part D's `csi_enabled` check. If that file
doesn't exist, nothing downstream matters — surface it to me immediately.
