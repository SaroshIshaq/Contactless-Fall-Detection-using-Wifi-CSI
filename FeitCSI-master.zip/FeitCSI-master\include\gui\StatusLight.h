/*
 * FeitCSI is the tool for extracting CSI information from supported intel NICs.
 * Copyright (C) 2023-2025 Miroslav Hutar.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef STATUS_LIGHT_H
#define STATUS_LIGHT_H

#include <gtkmm.h>
#include <string>

class StatusLight : public Gtk::DrawingArea
{
public:
    enum State
    {
        IDLE, // grey   - not measuring
        OK,   // green  - target-device CSI is arriving
        WARN, // yellow - CSI seen but nothing matches the target filter
        ERR   // red    - error, or measuring but no CSI at all
    };

    StatusLight();
    void init(Glib::RefPtr<Gtk::Box> box);
    void setState(State state, const std::string &text = "");

private:
    State state = IDLE;
    std::string label = "Idle";

    bool on_draw(const Cairo::RefPtr<Cairo::Context> &cr);
};

#endif
